package ru.web.notes.config;

public @interface Autowired {

}
