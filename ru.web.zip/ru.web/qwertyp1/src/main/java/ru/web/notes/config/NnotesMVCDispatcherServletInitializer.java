package ru.web.notes.config;




import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class NnotesMVCDispatcherServletInitializer extends AbstractAnnotationConfigDispatcherServletInitializer { 

	@Override 
	protected Class<?>[] getRootConfigClasses() { 
		return null; 
	}

	@Override 
	protected Class<?>[] getServletConfigClasses() { 
		return new Class[] {NotesConfig.class}; 
	}

	@Override 
	protected String[] getServletMappings() { 
		return new String[] {"/"}; 
	}
	@PatchMapping("/{id}")
	public String update(@ModelAttribute("webNote") WebNote webNote, @PathVariable("id") int id) {
		webNoteDAO.update(id, webNote);
		return "redirect:/notes";
	}



}


