package ru.web.notes.models;



public class WebNote {
	private int id;
	private String note;
	public int getid() {
	 return id;
	 
	}
	public void setid(int id) {
		this.id = id;
	}
    public String getNote() {
    	return note;
    }
    public void setNote(String note) {
    	this.note = note;
    	
    }

}
