package ru.web.notes.config;

public class AbstractAnnotationConfigDispatcherServletInitializer {

}
